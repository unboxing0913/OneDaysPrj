$(document).ready(function(){ 
	$('.bxslider').bxSlider({
		auto: true, 
		speed: 700, 
		pause: 4000, 
		mode:'fade', 
		autoControls: true, 
		pager:true, }); 
});

